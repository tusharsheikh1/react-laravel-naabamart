<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Slider extends Model
{
    protected $fillable = [
        'group', 'title', 'subtitle', 'image', 'mobile_image', 'link', 
        'desktop_size', 'mobile_size', 'order', 'status',
    ];

    protected $casts = [
        'status' => 'boolean',
        'order'  => 'integer',
    ];

    public function scopeActive($query) { return $query->where('status', true); }
    public function scopeGroup($query, string $group) { return $query->where('group', $group); }
    public function scopeOrdered($query) { return $query->orderBy('order')->orderBy('id'); }

    public static function forGroup(string $group): \Illuminate\Support\Collection
    {
        return static::group($group)->active()->ordered()->get();
    }

    public static function groupCatalogue(): array
    {
        return [
            'slider_1' => 'Slider 1 (Hero)',
            'slider_2' => 'Slider 2',
            'slider_3' => 'Slider 3',
            'slider_4' => 'Slider 4',
            'slider_5' => 'Slider 5',
        ];
    }
}