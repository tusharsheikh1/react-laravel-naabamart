<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\Color;
use App\Models\Size;
use App\Models\ProductVariant;
use App\Models\ShippingMethod;
use App\Models\ProductInteractionEvent;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Illuminate\Support\Facades\Log;

class CartController extends Controller
{
    /**
     * Display the cart page.
     */
    public function index()
    {
        $suggestedProducts = Product::inRandomOrder()->take(5)->get();

        return Inertia::render('Frontend/Cart', [
            'cart'              => session()->get('cart', []),
            'shippingMethods'   => ShippingMethod::where('status', true)->get(),
            'suggestedProducts' => $suggestedProducts,
        ]);
    }

    /**
     * Add an item to the cart or process a direct "Buy Now".
     */
    public function add(Request $request)
    {
        $request->validate([
            'product_id' => 'required|exists:products,id',
            'quantity'   => 'required|integer|min:1',
            'color_id'   => 'nullable',
            'size_id'    => 'nullable',
            'action'     => 'nullable|string',
        ]);

        $product = Product::findOrFail($request->product_id);

        // Convert JS 'null' strings / empty values to real PHP null
        $colorId = (!empty($request->color_id) && $request->color_id !== 'null') ? $request->color_id : null;
        $sizeId  = (!empty($request->size_id)  && $request->size_id  !== 'null') ? $request->size_id  : null;

        $color = $colorId ? Color::find($colorId) : null;
        $size  = $sizeId  ? Size::find($sizeId)   : null;

        $variant = ProductVariant::where('product_id', $product->id)
            ->where('color_id', $colorId)
            ->where('size_id',  $sizeId)
            ->first();

        // Prefix with 'p_' so PHP/JSON always treats it as a string key,
        // preventing the cart from silently becoming an empty array in JS.
        $cartKey = 'p_' . $product->id;
        if ($color) $cartKey .= '-c' . $color->id;
        if ($size)  $cartKey .= '-s' . $size->id;

        // Calculate price: base + variant adjustment, then apply discount
        $basePrice      = (float) $product->price;
        $priceAdjust    = $variant ? (float) $variant->price_adjustment : 0;
        $finalBasePrice = $basePrice + $priceAdjust;

        $finalPrice = $finalBasePrice;
        if ($product->discount_value > 0) {
            $finalPrice = $product->discount_type === 'percent'
                ? $finalBasePrice - ($finalBasePrice * ((float) $product->discount_value / 100))
                : $finalBasePrice - (float) $product->discount_value;
        }

        $cartItem = [
            'id'         => $product->id,
            'name'       => $product->name,
            'base_price' => $finalBasePrice,
            'price'      => $finalPrice,
            'quantity'   => (int) $request->quantity,
            'thumbnail'  => $product->thumbnail,
            'slug'       => $product->slug,
            'options'    => [
                'color_id' => $color ? $color->id   : null,
                'color'    => $color ? $color->name  : null,
                'size_id'  => $size  ? $size->id     : null,
                'size'     => $size  ? $size->name   : null,
            ],
        ];

        // =====================================================
        // BUY NOW — merge into regular cart then redirect
        // =====================================================
        if ($request->action === 'buy_now') {
            $cart = session()->get('cart', []);
            if (!is_array($cart)) {
                $cart = json_decode(json_encode($cart), true) ?? [];
            }

            if (isset($cart[$cartKey])) {
                $cart[$cartKey]['quantity'] += $request->quantity;
            } else {
                $cart[$cartKey] = $cartItem;
            }

            session()->put('cart', $cart);
            session()->forget('buy_now_cart');
            session()->put('checkout_context', 'cart');

            // FIX: Save and RELEASE the session lock BEFORE doing the analytics
            // DB insert. The database session driver holds a row-level lock for the
            // entire request. Any concurrent request (e.g. the view-tracking axios
            // call) that also needs the session will block until this lock is freed.
            // Calling session()->save() here commits the cart and releases the lock
            // immediately, so nothing downstream can block the checkout redirect.
            session()->save();

            // Analytics runs AFTER the session lock is fully released
            $this->logAddToCartEvent($product->id, $request->quantity, $colorId, $sizeId, $finalPrice, 'buy_now');

            return redirect()->route('checkout.index');
        }

        // =====================================================
        // STANDARD ADD TO CART
        // =====================================================
        $cart = session()->get('cart', []);
        if (!is_array($cart)) {
            $cart = json_decode(json_encode($cart), true) ?? [];
        }

        if (isset($cart[$cartKey])) {
            $cart[$cartKey]['quantity'] += $request->quantity;
        } else {
            $cart[$cartKey] = $cartItem;
        }

        session()->put('cart', $cart);

        // FIX: Save and RELEASE the session lock BEFORE doing the analytics
        // DB insert. Without this, a concurrent view-tracking axios.post (which
        // also touches the session) can hold the lock, causing this cart write to
        // silently time out — yet back()->with('success') still fires, showing a
        // false "added to cart" toast while the item was never actually saved.
        session()->save();

        // Analytics runs AFTER the session lock is fully released
        $this->logAddToCartEvent($product->id, $request->quantity, $colorId, $sizeId, $finalPrice);

        return back()->with('success', 'Product added to cart!');
    }

    /**
     * Log an add_to_cart analytics event safely.
     * This method must only be called AFTER session()->save() so it never
     * competes with session lock acquisition in concurrent requests.
     */
    private function logAddToCartEvent(
        int    $productId,
        int    $quantity,
        ?int   $colorId,
        ?int   $sizeId,
        float  $finalPrice,
        string $action = 'add_to_cart'
    ): void {
        try {
            if (class_exists('\App\Models\ProductInteractionEvent')) {
                ProductInteractionEvent::create([
                    'product_id' => $productId,
                    'user_id'    => auth()->check() ? auth()->id() : null,
                    'session_id' => session()->getId(),
                    'event_type' => 'add_to_cart',
                    'metadata'   => json_encode([
                        'quantity' => $quantity,
                        'color_id' => $colorId,
                        'size_id'  => $sizeId,
                        'price'    => $finalPrice,
                        'action'   => $action,
                    ]),
                ]);
            }
        } catch (\Exception $e) {
            Log::error('Cart Analytics Error: ' . $e->getMessage());
        }
    }

    /**
     * Update the quantity of a specific cart item.
     */
    public function update(Request $request)
    {
        $request->validate([
            'cart_key'      => 'required|string',
            'quantity'      => 'required|integer|min:1',
            'checkout_type' => 'nullable|string',
        ]);

        $sessionKey = $request->checkout_type === 'buy_now' ? 'buy_now_cart' : 'cart';
        $cart = session()->get($sessionKey, []);

        if (!is_array($cart)) {
            $cart = json_decode(json_encode($cart), true) ?? [];
        }

        if (isset($cart[$request->cart_key])) {
            $cart[$request->cart_key]['quantity'] = (int) $request->quantity;
            session()->put($sessionKey, $cart);
            session()->save();
        }

        return back();
    }

    /**
     * Remove an item from the cart.
     */
    public function remove(Request $request)
    {
        $request->validate([
            'cart_key'      => 'required|string',
            'checkout_type' => 'nullable|string',
        ]);

        $sessionKey = $request->checkout_type === 'buy_now' ? 'buy_now_cart' : 'cart';
        $cart = session()->get($sessionKey, []);

        if (!is_array($cart)) {
            $cart = json_decode(json_encode($cart), true) ?? [];
        }

        if (isset($cart[$request->cart_key])) {
            unset($cart[$request->cart_key]);
            session()->put($sessionKey, $cart);
            session()->save();
        }

        return back();
    }

    /**
     * Clear the entire standard cart.
     */
    public function clear()
    {
        session()->forget('cart');
        session()->save();
        return back()->with('success', 'Cart cleared.');
    }
}