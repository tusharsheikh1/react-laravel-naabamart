<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Services\AnalyticsEventService;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Log;

class AnalyticsController extends Controller
{
    protected $analyticsService;

    public function __construct(AnalyticsEventService $analyticsService)
    {
        $this->analyticsService = $analyticsService;
    }

    /**
     * Store a tracking event sent from the frontend.
     * Updated to include 'checkout_start' in allowed event types.
     */
    public function trackEvent(Request $request)
    {
        // FIX: Release the session lock immediately before doing anything else.
        //
        // The database session driver holds a row-level lock on the session row
        // for the entire request lifecycle. When a product page loads, the frontend
        // fires axios.post('/analytics/track') for the 'view' event at the same time
        // the user might click "Add to Cart" or "Buy Now". Both requests need the
        // session. If the analytics request grabs the lock first, the cart.add request
        // blocks — its session write silently fails, but back()->with('success') still
        // returns, showing a false "added to cart" toast with nothing actually saved.
        //
        // Calling session()->save() here commits any pending session data and releases
        // the lock immediately, so this endpoint never blocks concurrent cart requests.
        session()->save();

        // Use manual Validator so it doesn't trigger a 302 redirect on failure
        $validator = Validator::make($request->all(), [
            'product_id'  => 'nullable|exists:products,id',
            'event_type'  => 'required|in:view,add_to_cart,remove_from_cart,wishlist,compare,scroll,heatmap_click,checkout_start',
            'event_value' => 'nullable|numeric',
            'metadata'    => 'nullable|array',
        ]);

        if ($validator->fails()) {
            Log::warning('Analytics Validation Failed', $validator->errors()->toArray());
            return response()->json(['status' => 'error', 'errors' => $validator->errors()], 422);
        }

        try {
            $this->analyticsService->logEvent(
                $request->product_id,
                $request->event_type,
                $request->event_value,
                $request->metadata ?? []
            );

            return response()->json(['status' => 'success']);
        } catch (\Exception $e) {
            Log::error('Analytics DB Insert failed: ' . $e->getMessage());
            return response()->json(['status' => 'error', 'message' => 'Server error'], 500);
        }
    }
}