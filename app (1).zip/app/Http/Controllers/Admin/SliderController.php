<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Slider;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Illuminate\Support\Facades\Storage;

class SliderController extends Controller
{
    // ─── Index ────────────────────────────────────────────────────────────────

    public function index()
    {
        $sliders = Slider::orderBy('group')->orderBy('order')->orderBy('id')->get();
        $grouped = $sliders->groupBy('group');

        return Inertia::render('Admin/Sliders/Index', [
            'grouped'        => $grouped,
            'groupCatalogue' => Slider::groupCatalogue(),
        ]);
    }

    // ─── Create ───────────────────────────────────────────────────────────────

    public function create()
    {
        return Inertia::render('Admin/Sliders/Create', [
            'groupCatalogue' => Slider::groupCatalogue(),
        ]);
    }

    // ─── Store ────────────────────────────────────────────────────────────────

    public function store(Request $request)
    {
        $validated = $request->validate([
            'group'        => 'required|string|in:' . implode(',', array_keys(Slider::groupCatalogue())),
            'title'        => 'nullable|string|max:255',
            'subtitle'     => 'nullable|string|max:255',
            'image'        => 'required|image|mimes:jpeg,png,jpg,webp|max:4096',
            'mobile_image' => 'nullable|image|mimes:jpeg,png,jpg,webp|max:4096',
            'link'         => 'nullable|url',
            'desktop_size' => 'nullable|string',
            'mobile_size'  => 'nullable|string',
            'order'        => 'nullable|integer',
            'status'       => 'nullable|boolean',
        ]);

        $validated['image'] = $request->file('image')->store('sliders', 'public');

        if ($request->hasFile('mobile_image')) {
            $validated['mobile_image'] = $request->file('mobile_image')->store('sliders', 'public');
        }

        $validated['status'] = $request->boolean('status', true);

        Slider::create($validated);

        return redirect()->route('admin.sliders.index')->with('success', 'Slider created successfully.');
    }

    // ─── Edit ─────────────────────────────────────────────────────────────────

    public function edit(Slider $slider)
    {
        return Inertia::render('Admin/Sliders/Edit', [
            'slider'         => $slider,
            'groupCatalogue' => Slider::groupCatalogue(),
        ]);
    }

    // ─── Update ───────────────────────────────────────────────────────────────

    public function update(Request $request, Slider $slider)
    {
        $validated = $request->validate([
            'group'        => 'required|string|in:' . implode(',', array_keys(Slider::groupCatalogue())),
            'title'        => 'nullable|string|max:255',
            'subtitle'     => 'nullable|string|max:255',
            'image'        => 'nullable|image|mimes:jpeg,png,jpg,webp|max:4096',
            'mobile_image' => 'nullable|image|mimes:jpeg,png,jpg,webp|max:4096',
            'link'         => 'nullable|url',
            'desktop_size' => 'nullable|string',
            'mobile_size'  => 'nullable|string',
            'order'        => 'nullable|integer',
            'status'       => 'nullable|boolean',
        ]);

        if ($request->hasFile('image')) {
            if ($slider->image) {
                Storage::disk('public')->delete($slider->image);
            }
            $validated['image'] = $request->file('image')->store('sliders', 'public');
        }

        if ($request->hasFile('mobile_image')) {
            if ($slider->mobile_image) {
                Storage::disk('public')->delete($slider->mobile_image);
            }
            $validated['mobile_image'] = $request->file('mobile_image')->store('sliders', 'public');
        }

        // Allow removing the mobile image
        if ($request->input('remove_mobile_image') === '1') {
            if ($slider->mobile_image) {
                Storage::disk('public')->delete($slider->mobile_image);
            }
            $validated['mobile_image'] = null;
        }

        $validated['status'] = $request->boolean('status', true);

        $slider->update($validated);

        return redirect()->route('admin.sliders.index')->with('success', 'Slider updated successfully.');
    }

    // ─── Destroy ──────────────────────────────────────────────────────────────

    public function destroy(Slider $slider)
    {
        if ($slider->image) {
            Storage::disk('public')->delete($slider->image);
        }
        if ($slider->mobile_image) {
            Storage::disk('public')->delete($slider->mobile_image);
        }

        $slider->delete();

        return redirect()->route('admin.sliders.index')->with('success', 'Slider deleted successfully.');
    }
}