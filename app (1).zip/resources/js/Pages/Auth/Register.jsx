import { useEffect, useState } from 'react';
import { Head, Link, useForm } from '@inertiajs/react';
import InputError from '@/Components/InputError';
import SocialButton from '@/Components/SocialButton';

export default function Register() {
    const { data, setData, post, processing, errors, reset } = useForm({
        name: '', // We can use this for the "Mobile" or "Email" depending on logic
        email: '',
        password: '',
        password_confirmation: '',
        mobile: '', // Field added for UI, needs backend support
    });

    const [showPassword, setShowPassword] = useState(false);
    const [showConfirmPassword, setShowConfirmPassword] = useState(false);

    useEffect(() => {
        return () => {
            reset('password', 'password_confirmation');
        };
    }, []);

    const submit = (e) => {
        e.preventDefault();
        // Backend currently requires 'name', so we mock it if not present in UI
        if(!data.name) data.name = "New User"; 
        post(route('register'));
    };

    return (
        <div className="flex min-h-screen items-center justify-center bg-gray-50 px-4 py-10 sm:px-6 lg:px-8">
            <Head title="Register" />

            <div className="w-full max-w-md rounded-3xl bg-white p-8 shadow-2xl">
                <div className="mb-8 text-center">
                    <h2 className="text-3xl font-bold text-gray-900">Register</h2>
                </div>

                <form onSubmit={submit} className="space-y-5">
                    
                    {/* Mobile Number Input */}
                    <div className="space-y-1">
                        <label className="text-sm font-medium text-gray-700">Enter your mobile number</label>
                        <div className="relative flex rounded-xl border border-gray-300 shadow-sm focus-within:border-black focus-within:ring-1 focus-within:ring-black">
                            
                            <input
                                type="text"
                                name="mobile"
                                value={data.mobile}
                                onChange={(e) => setData('mobile', e.target.value)}
                                className="block w-full border-0 bg-transparent py-3 pl-4 text-gray-900 placeholder:text-gray-400 focus:ring-0 sm:text-sm"
                                placeholder="1712345678"
                            />
                            <div className="flex items-center pr-3">
                                <div className="rounded-full bg-black p-0.5">
                                    <svg className="h-3 w-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" />
                                    </svg>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Email Input */}
                    <div className="space-y-1">
                        <label className="text-sm font-medium text-gray-700">Enter your Email</label>
                        <input
                            id="email"
                            type="email"
                            name="email"
                            value={data.email}
                            onChange={(e) => setData('email', e.target.value)}
                            required
                            className="block w-full rounded-xl border-gray-300 py-3 shadow-sm focus:border-black focus:ring-black sm:text-sm"
                            placeholder="abc12@gmail.com"
                        />
                        <InputError message={errors.email} className="mt-1" />
                    </div>

                    {/* Password Input */}
                    <div className="space-y-1">
                        <label className="text-sm font-medium text-gray-700">Enter your password</label>
                        <div className="relative rounded-xl border border-gray-300 shadow-sm focus-within:border-black focus-within:ring-1 focus-within:ring-black">
                            <input
                                id="password"
                                type={showPassword ? "text" : "password"}
                                name="password"
                                value={data.password}
                                onChange={(e) => setData('password', e.target.value)}
                                required
                                className="block w-full border-0 bg-transparent py-3 pl-4 pr-10 text-gray-900 placeholder:text-gray-400 focus:ring-0 sm:text-sm"
                                placeholder="*************"
                            />
                             <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute inset-y-0 right-0 flex items-center pr-3 text-gray-400 hover:text-gray-600">
                                <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                                </svg>
                            </button>
                        </div>
                        <InputError message={errors.password} className="mt-1" />
                    </div>

                     {/* Confirm Password Input */}
                     <div className="space-y-1">
                        <label className="text-sm font-medium text-gray-700">Re-Enter your password</label>
                        <div className="relative rounded-xl border border-gray-300 shadow-sm focus-within:border-black focus-within:ring-1 focus-within:ring-black">
                            <input
                                id="password_confirmation"
                                type={showConfirmPassword ? "text" : "password"}
                                name="password_confirmation"
                                value={data.password_confirmation}
                                onChange={(e) => setData('password_confirmation', e.target.value)}
                                required
                                className="block w-full border-0 bg-transparent py-3 pl-4 pr-10 text-gray-900 placeholder:text-gray-400 focus:ring-0 sm:text-sm"
                                placeholder="*************"
                            />
                             <button type="button" onClick={() => setShowConfirmPassword(!showConfirmPassword)} className="absolute inset-y-0 right-0 flex items-center pr-3 text-gray-400 hover:text-gray-600">
                                <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                                </svg>
                            </button>
                        </div>
                        <InputError message={errors.password_confirmation} className="mt-1" />
                    </div>

                    <button
                        type="submit"
                        disabled={processing}
                        className="mt-6 w-full rounded-xl bg-gray-900 py-3.5 text-sm font-bold text-white shadow-md transition hover:bg-black focus:outline-none focus:ring-2 focus:ring-black focus:ring-offset-2 disabled:opacity-50"
                    >
                        Sign up
                    </button>

                    <div className="text-center text-sm text-gray-600">
                        Don't have an account?{' '}
                        <Link href={route('login')} className="font-bold text-black hover:underline">
                            Sign in
                        </Link>
                    </div>

                    <div className="relative my-6">
                        <div className="absolute inset-0 flex items-center">
                            <div className="w-full border-t border-gray-200" />
                        </div>
                        <div className="relative flex justify-center text-sm">
                            <span className="bg-white px-2 text-gray-500">or</span>
                        </div>
                    </div>

                    <div className="space-y-3">
                         <SocialButton
                            text="Continue with Google"
                            icon={
                                <svg className="h-5 w-5" viewBox="0 0 24 24">
                                    <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4" />
                                    <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" />
                                    <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05" />
                                    <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335" />
                                </svg>
                            }
                        />
                        <SocialButton
                            text="Continue with Apple"
                            icon={
                                <svg className="h-5 w-5 text-black" viewBox="0 0 24 24" fill="currentColor">
                                    <path d="M17.05 20.28c-.98.95-2.05.8-3.08.35-1.09-.46-2.09-.48-3.24 0-1.44.62-2.2.44-3.06-.35C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.74 1.18 0 2.29-.93 3.57-.93 1.6.02 2.65.7 3.25 1.6-2.92 1.5-2.42 5.5.35 6.69-.64 1.76-1.5 3.35-2.25 4.87zM12.03 5.38c-.28-1.59 1.14-3.17 2.53-3.38.3.1.28.1.33 1.76-.02 1.67-1.35 3.2-2.86 3.05z" />
                                </svg>
                            }
                        />
                    </div>
                </form>
            </div>
        </div>
    );
}